import time
import matplotlib.pyplot as plt
import numpy as np
import clr                                          # 命令行执行这两句： pip uninstall clr    pip install pythonnet
import time
clr.AddReference('c:\OpenHardwareMonitorLib.dll')   # 把dll放到这里，理论上其他位置也可以，但是。。。
from OpenHardwareMonitor.Hardware import Computer 
 
PC = Computer() 
PC.CPUEnabled = True 
PC.GPUEnabled = True  
PC.Open()
CPU = PC.Hardware[0]
GPU = PC.Hardware[1]
dot=200 #x轴点数
i=0
xdata = [i for i in range(dot)] 
ydata_CPU = [0 for i in range(dot)]
ydata_GPU = [0 for i in range(dot)]
plt.ion() 
plt.rcParams['axes.facecolor'] = 'black'
figure, ax = plt.subplots(figsize=(16, 4))
curve_CPU, = ax.plot([], [])
curve_GPU, = ax.plot([], [])
curve_CPU.set_xdata(xdata)
curve_GPU.set_xdata(xdata)
ax.set_xlim([0, dot])
ax.set_ylim([0, 100])
ax.set_xticks(range(0, dot+1, 10))
ax.set_yticks(range(0, 101, 20))
ax.grid()

while True:
    time.sleep(0.2)
    CPU.Update()
    GPU.Update()
    CPU_load = CPU.Sensors[0].Value
    GPU_load = GPU.Sensors[4].Value  
    ydata_CPU[i] = CPU_load
    curve_CPU.set_ydata(ydata_CPU)
    ydata_GPU[i] = GPU_load
    curve_GPU.set_ydata(ydata_GPU)    
    figure.canvas.draw()
    figure.canvas.flush_events()
    i=i+1
    if i >= dot: #开始向左滚动
        i = dot-1
        for j in range(dot-1):
            ydata_CPU[j] = ydata_CPU[j+1]
            ydata_GPU[j] = ydata_GPU[j+1]
        
        


        








     
    



    

