import cv2

#########################################################
threshold = 0.6  # 检测阈值
wCam, hCam = 640, 480  # 用于设置camera展示窗口的大小
#########################################################

# 打开摄像头
#cap = cv2.VideoCapture(0)  # 计算机自带摄像头，如果是外置摄像头，需要更改末尾数字
cap = cv2.VideoCapture('Road_traffic_video2.mp4')
cap.set(3, wCam)
cap.set(4, hCam)

# 导入coco.names中提前被定义好的类，作为分类结果的标签
classNames = []
classFile = "coco.names"
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')
# print(className)

# 导入配置文件
configPath = 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'
weightsPath = 'frozen_inference_graph.pb'

# 配置检测网络（可以简单地认为就是一些配置，具体细节没必要深究）
net = cv2.dnn_DetectionModel(weightsPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0 / 127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)

# 运行网络进行检测，并返回bbox，以及被检测物体的种类
while True:
    success, img = cap.read()
    classIDs, confs, bbox = net.detect(img, confThreshold=threshold)
    print('\n')
    print(classIDs, bbox)
    if len(classIDs) != 0:
        for classID, conf, box in zip(classIDs.flatten(), confs.flatten(), bbox):
            # 画检测框
            cv2.rectangle(img, box, color=(255, 0, 0), thickness=1)
            # 写分类结果 (box[0] box[1] 对应左上角 x y)
            cv2.putText(img, classNames[classID - 1].upper(), (box[0] + 10, box[1] + 30), cv2.FONT_ITALIC, 1, (0, 255, 0), 2)
            # 写分类结果的置信度
            cv2.putText(img, str(round(conf*100, 1))+'%', (box[0] + 180, box[1] + 30), cv2.FONT_ITALIC, 1, (0, 255, 0), 2)

        cv2.putText(img, 'ESC=Pause', (10,30), cv2.FONT_ITALIC, 1, (0, 0, 255), 2)
        cv2.imshow('Output', img)

        if cv2.waitKey(1) == 27:                     # ESC, 按键检测，按长一点,按一次暂停(方便看输出信息)，再按恢复
            while True:
                if cv2.waitKey(1) == 27:
                    break

